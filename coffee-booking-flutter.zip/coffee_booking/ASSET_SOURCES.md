# Coffee image sources

Downloaded from Unsplash at 900-pixel width for this demo. No remote images are requested by the app at runtime.

| Local image | Source |
| --- | --- |
| latte.jpg | https://images.unsplash.com/photo-1541167760496-1628856ab772 |
| espresso.jpg | https://images.unsplash.com/photo-1510707577719-ae7c14805e3a |
| cappuccino.jpg | https://images.unsplash.com/photo-1572442388796-11668a67e53d |
| cold_brew.jpg | https://images.unsplash.com/photo-1461023058943-07fcbe16d735 |
| mocha.jpg | https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd |

Photos illustrate the sample menu and are not photographs of products from a real connected café.
